# scripts/plot_comparison.py
import json
from pathlib import Path
import matplotlib.pyplot as plt

# We will use summary.json if you only have a single run,
# or compare_results.json if you later add multiple experiments.

summary_path = Path("logs/summary.json")
compare_path = Path("logs/compare_results.json")

if compare_path.exists():
    # Multiple experiments case
    data = json.loads(compare_path.read_text(encoding="utf-8"))
    names = []
    hits = []
    mrrs = []

    for r in data:
        if "summary" not in r:
            continue
        names.append(r["name"])
        s = r["summary"]
        hits.append(s.get("hit_at_k", 0.0))
        mrrs.append(s.get("mrr", 0.0))

    if not names:
        print("No valid experiments in compare_results.json")
        raise SystemExit(1)

    # Plot Hit@K
    plt.figure(figsize=(8, 4))
    plt.bar(names, hits)
    plt.title("Hit@K by experiment")
    plt.ylabel("Hit@K")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("logs/hit_at_k_comparison.png")
    print("Saved logs/hit_at_k_comparison.png")

    # Plot MRR
    plt.figure(figsize=(8, 4))
    plt.bar(names, mrrs)
    plt.title("MRR by experiment")
    plt.ylabel("MRR")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig("logs/mrr_comparison.png")
    print("Saved logs/mrr_comparison.png")

else:
    # Single summary case (what you have now)
    if not summary_path.exists():
        print("No summary.json found in logs/. Run python -m src.eval_runner first.")
        raise SystemExit(1)

    s = json.loads(summary_path.read_text(encoding="utf-8"))
    metrics = ["hit_at_k", "mrr"]
    values = [s.get("hit_at_k", 0.0), s.get("mrr", 0.0)]

    plt.figure(figsize=(6, 4))
    plt.bar(metrics, values)
    plt.title("RAG Retrieval Metrics (single run)")
    plt.ylabel("Value")
    plt.tight_layout()
    plt.savefig("logs/metrics_single_run.png")
    print("Saved logs/metrics_single_run.png")