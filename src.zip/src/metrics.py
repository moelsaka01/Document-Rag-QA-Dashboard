from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class PerQueryMetrics:
    hit_at_k: float
    reciprocal_rank: float
    first_relevant_rank: Optional[int]


@dataclass
class AggregateMetrics:
    hit_at_k: float
    mrr: float
    n_queries: int


def compute_per_query_metrics(
    retrieved_doc_ids: List[str],
    relevant_doc_ids: List[str],
    k: int,
) -> PerQueryMetrics:
    relevant_set = set(relevant_doc_ids)
    top_k_docs = retrieved_doc_ids[:k]

    hit = 1.0 if any(doc_id in relevant_set for doc_id in top_k_docs) and relevant_set else 0.0

    first_rank: Optional[int] = None
    for idx, doc_id in enumerate(retrieved_doc_ids):
        if doc_id in relevant_set:
            first_rank = idx + 1
            break

    rr = 1.0 / first_rank if first_rank is not None else 0.0

    return PerQueryMetrics(hit_at_k=hit, reciprocal_rank=rr, first_relevant_rank=first_rank)


def aggregate_metrics(per_query: List[PerQueryMetrics]) -> AggregateMetrics:
    if not per_query:
        return AggregateMetrics(hit_at_k=0.0, mrr=0.0, n_queries=0)

    n = len(per_query)
    hit_sum = sum(m.hit_at_k for m in per_query)
    rr_sum = sum(m.reciprocal_rank for m in per_query)

    return AggregateMetrics(
        hit_at_k=hit_sum / n,
        mrr=rr_sum / n,
        n_queries=n,
    )
