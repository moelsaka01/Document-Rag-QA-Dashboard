from typing import List
from pydantic import BaseModel, Field


class AskRequest(BaseModel):
    query: str = Field(..., description="User question about the documents")
    top_k: int = Field(3, ge=1, le=10, description="Number of chunks to retrieve")


class RetrievedChunkSchema(BaseModel):
    doc_id: str
    chunk_id: int
    score: float
    text_preview: str


class AskResponse(BaseModel):
    answer: str
    retrieved_chunks: List[RetrievedChunkSchema]
