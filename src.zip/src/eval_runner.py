from __future__ import annotations

import json
from pathlib import Path
from typing import List

import httpx
from rich.console import Console
from rich.table import Table

from .config import get_settings
from .dataset import load_eval_dataset
from .metrics import compute_per_query_metrics, aggregate_metrics


console = Console()


async def evaluate_once() -> None:
    settings = get_settings()

    console.rule("[bold cyan]RAG Evaluation & Benchmarking")
    console.print(f"[bold]RAG base URL:[/bold] {settings.rag_api_base_url}")
    console.print(f"[bold]Ask path:[/bold] {settings.rag_ask_path}")
    console.print(f"[bold]Top K:[/bold] {settings.rag_top_k}")
    console.print(f"[bold]Dataset:[/bold] {settings.eval_dataset_path}")

    examples = load_eval_dataset(settings.eval_dataset_path)
    console.print(f"[green]Loaded {len(examples)} evaluation queries.[/green]\n")

    client = httpx.AsyncClient(timeout=30.0)

    per_query_metrics = []
    log_path = Path(settings.eval_logs_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("", encoding="utf-8")

    for ex in examples:
        console.print(f"[bold]Query {ex.id}:[/bold] {ex.query}")
        try:
            resp = await client.post(
                settings.rag_api_base_url.rstrip("/") + settings.rag_ask_path,
                json={"query": ex.query, "top_k": settings.rag_top_k},
            )
            resp.raise_for_status()
        except Exception as exc:
            console.print(f"[red]Error calling RAG API:[/red] {exc}")
            record = {
                "id": ex.id,
                "query": ex.query,
                "error": str(exc),
            }
            with log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
            continue

        data = resp.json()
        retrieved_chunks = data.get("retrieved_chunks", [])
        retrieved_doc_ids: List[str] = [c.get("doc_id", "") for c in retrieved_chunks]

        m = compute_per_query_metrics(
            retrieved_doc_ids=retrieved_doc_ids,
            relevant_doc_ids=ex.relevant_doc_ids,
            k=settings.rag_top_k,
        )
        per_query_metrics.append(m)

        console.print(
            f"  Relevant docs: {ex.relevant_doc_ids} | Retrieved docs (top {settings.rag_top_k}): {retrieved_doc_ids[:settings.rag_top_k]}"
        )
        console.print(
            f"  Hit@{settings.rag_top_k}: [bold]{m.hit_at_k}[/bold], Reciprocal Rank: [bold]{m.reciprocal_rank:.3f}[/bold] (rank={m.first_relevant_rank})\n"
        )

        record = {
            "id": ex.id,
            "query": ex.query,
            "relevant_doc_ids": ex.relevant_doc_ids,
            "retrieved_doc_ids": retrieved_doc_ids,
            "hit_at_k": m.hit_at_k,
            "reciprocal_rank": m.reciprocal_rank,
            "first_relevant_rank": m.first_relevant_rank,
        }
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")

    await client.aclose()

    agg = aggregate_metrics(per_query_metrics)

    summary = {
        "hit_at_k": agg.hit_at_k,
        "mrr": agg.mrr,
        "n_queries": agg.n_queries,
        "k": settings.rag_top_k,
    }
    summary_path = Path(settings.eval_summary_path)
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    console.rule("[bold green]Summary")
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Metric")
    table.add_column("Value")

    table.add_row(f"Hit@{settings.rag_top_k}", f"{agg.hit_at_k:.3f}")
    table.add_row("MRR", f"{agg.mrr:.3f}")
    table.add_row("Num queries", str(agg.n_queries))

    console.print(table)
    console.print(f"\n[cyan]Per-query logs:[/cyan] {log_path}")
    console.print(f"[cyan]Summary JSON:[/cyan] {summary_path}")


if __name__ == "__main__":
    import asyncio

    asyncio.run(evaluate_once())
