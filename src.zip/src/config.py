from pydantic import BaseModel
from functools import lru_cache
import os


class Settings(BaseModel):
    rag_api_base_url: str = "http://127.0.0.1:8000"
    rag_ask_path: str = "/ask"
    rag_top_k: int = 5
    eval_dataset_path: str = "data/eval/qa_dataset.jsonl"
    eval_logs_path: str = "logs/eval_logs.jsonl"
    eval_summary_path: str = "logs/summary.json"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings(
        rag_api_base_url=os.getenv("RAG_API_BASE_URL", "http://127.0.0.1:8000"),
        rag_ask_path=os.getenv("RAG_ASK_PATH", "/ask"),
        rag_top_k=int(os.getenv("RAG_TOP_K", "5")),
        eval_dataset_path=os.getenv("EVAL_DATASET_PATH", "data/eval/qa_dataset.jsonl"),
        eval_logs_path=os.getenv("EVAL_LOGS_PATH", "logs/eval_logs.jsonl"),
        eval_summary_path=os.getenv("EVAL_SUMMARY_PATH", "logs/summary.json"),
    )
