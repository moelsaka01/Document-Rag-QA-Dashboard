from __future__ import annotations

from dataclasses import dataclass
from typing import List
from pathlib import Path
import json


@dataclass
class EvalExample:
    id: str
    query: str
    relevant_doc_ids: List[str]


def load_eval_dataset(path: str) -> List[EvalExample]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Evaluation dataset not found at {p}")

    examples: List[EvalExample] = []
    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            examples.append(
                EvalExample(
                    id=str(obj.get("id")),
                    query=obj.get("query", ""),
                    relevant_doc_ids=list(obj.get("relevant_doc_ids", [])),
                )
            )
    return examples
