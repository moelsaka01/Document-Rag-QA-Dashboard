from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

from .rag_pipeline import RAGPipeline
from .schemas import AskRequest, AskResponse, RetrievedChunkSchema

app = FastAPI(
    title="Document RAG QA Platform",
    description="Simple Retrieval Augmented Generation style QA over local documents.",
    version="1.0.0",
)

# Initialize pipeline once at startup
rag_pipeline = RAGPipeline()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/meta")
def meta():
    """
    Return index statistics as JSON so external tools can query the service.
    """
    stats = rag_pipeline.get_index_stats()
    return JSONResponse(content=stats)


@app.post("/ask", response_model=AskResponse)
def ask(request: AskRequest):
    answer, retrieved = rag_pipeline.generate_answer(request.query, top_k=request.top_k)
    retrieved_schemas = [
        RetrievedChunkSchema(
            doc_id=c.doc_id,
            chunk_id=c.chunk_id,
            score=round(c.score, 4),
            text_preview=(c.text[:200] + "...") if len(c.text) > 200 else c.text,
        )
        for c in retrieved
    ]
    return AskResponse(answer=answer, retrieved_chunks=retrieved_schemas)


@app.get("/app", response_class=HTMLResponse)
def app_with_theme_toggle():
    # pull stats for rendering into the page
    stats = rag_pipeline.get_index_stats()
    total_chunks = stats.get("total_chunks", 0)
    doc_count = stats.get("doc_count", 0)

    # template with placeholders; we will replace them below
    html_template = """
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Document RAG QA</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style>
            :root {
                --bg: #f9fafb;
                --bg-elevated: #ffffff;
                --bg-answer: #ffffff;
                --border-subtle: #e5e7eb;
                --border-strong: #d1d5db;
                --text-main: #111827;
                --text-subtle: #6b7280;
                --accent: #2563eb;
                --accent-soft: #dbeafe;
                --chip-bg: #eff6ff;
                --chip-border: #bfdbfe;
                --shadow-card: 0 20px 40px rgba(15,23,42,0.08);
            }

            body.theme-dark {
                --bg: radial-gradient(circle at top, #1d4ed8 0, #020617 50%, #000 100%);
                --bg-elevated: rgba(15,23,42,0.96);
                --bg-answer: radial-gradient(circle at top left, rgba(56,189,248,0.12), rgba(15,23,42,1));
                --border-subtle: rgba(31,41,55,0.9);
                --border-strong: rgba(148,163,184,0.4);
                --text-main: #e5e7eb;
                --text-subtle: #9ca3af;
                --accent: #38bdf8;
                --accent-soft: rgba(56,189,248,0.18);
                --chip-bg: rgba(15,23,42,0.9);
                --chip-border: rgba(55,65,81,0.9);
                --shadow-card: 0 28px 60px rgba(0,0,0,0.8);
            }

            * { box-sizing: border-box; }

            body {
                margin: 0;
                font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
                background: var(--bg);
                color: var(--text-main);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 16px;
            }

            .shell {
                max-width: 960px;
                width: 100%;
            }

            .card {
                background: var(--bg-elevated);
                border-radius: 20px;
                padding: 20px 20px 16px;
                border: 1px solid var(--border-strong);
                box-shadow: var(--shadow-card);
            }

            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 10px;
                margin-bottom: 10px;
            }

            .title-block {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }

            .title {
                font-size: 1.3rem;
                font-weight: 600;
            }

            .subtitle {
                font-size: 0.85rem;
                color: var(--text-subtle);
            }

            .meta-row {
                font-size: 0.78rem;
                color: var(--text-subtle);
                margin-top: 4px;
            }

            .pill {
                font-size: 0.75rem;
                padding: 4px 10px;
                border-radius: 999px;
                border: 1px solid var(--chip-border);
                background: var(--chip-bg);
                color: var(--text-subtle);
            }

            .right-controls {
                display: flex;
                flex-direction: column;
                gap: 6px;
                align-items: flex-end;
            }

            .theme-toggle {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                font-size: 0.8rem;
            }

            .theme-toggle button {
                border-radius: 999px;
                border: 1px solid var(--border-strong);
                padding: 3px 10px;
                background: transparent;
                color: var(--text-subtle);
                font-size: 0.75rem;
                cursor: pointer;
            }

            .theme-toggle button.active {
                background: var(--accent-soft);
                color: var(--accent);
                border-color: var(--accent);
            }

            .field-label {
                font-size: 0.8rem;
                color: var(--text-subtle);
                margin-bottom: 4px;
                margin-top: 12px;
            }

            textarea {
                width: 100%;
                min-height: 90px;
                resize: vertical;
                padding: 10px 12px;
                border-radius: 14px;
                border: 1px solid var(--border-strong);
                font-size: 0.95rem;
                background: transparent;
                color: var(--text-main);
            }

            textarea::placeholder {
                color: var(--text-subtle);
            }

            textarea:focus {
                outline: none;
                border-color: var(--accent);
                box-shadow: 0 0 0 1px var(--accent-soft);
            }

            .controls {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 10px;
                margin-top: 10px;
            }

            input[type="number"] {
                width: 72px;
                padding: 6px 8px;
                border-radius: 999px;
                border: 1px solid var(--border-strong);
                background: transparent;
                color: var(--text-main);
                font-size: 0.8rem;
            }

            .btn-primary {
                padding: 8px 16px;
                border-radius: 999px;
                border: none;
                background: linear-gradient(135deg, #38bdf8, #4f46e5);
                color: white;
                font-weight: 500;
                cursor: pointer;
                font-size: 0.9rem;
                display: inline-flex;
                align-items: center;
                gap: 6px;
                box-shadow: 0 12px 30px rgba(37,99,235,0.35);
            }

            .btn-primary:disabled {
                opacity: 0.6;
                cursor: default;
                box-shadow: none;
            }

            .btn-secondary {
                padding: 6px 10px;
                border-radius: 8px;
                border: 1px solid var(--border-strong);
                background: transparent;
                cursor: pointer;
                font-size: 0.8rem;
            }

            .status {
                font-size: 0.8rem;
                color: var(--text-subtle);
                margin-top: 6px;
                min-height: 18px;
            }

            .answer-block {
                margin-top: 16px;
                padding: 14px;
                border-radius: 16px;
                background: var(--bg-answer);
                border: 1px solid var(--border-subtle);
            }

            .answer-title {
                font-size: 0.95rem;
                font-weight: 600;
                margin-bottom: 6px;
            }

            .answer-text {
                font-size: 0.9rem;
                white-space: pre-wrap;
            }

            .chips {
                margin-top: 10px;
                display: flex;
                flex-wrap: wrap;
                gap: 6px;
            }

            .chip {
                font-size: 0.75rem;
                padding: 3px 8px;
                border-radius: 999px;
                border: 1px solid var(--chip-border);
                background: var(--chip-bg);
                color: var(--text-subtle);
            }

            .chunks-list {
                margin-top: 12px;
                border-top: 1px solid var(--border-subtle);
                padding-top: 8px;
            }

            .chunk-item {
                margin-bottom: 8px;
                padding: 8px;
                border-radius: 10px;
                border: 1px solid var(--border-subtle);
                font-size: 0.82rem;
            }

            .chunk-header {
                display: flex;
                gap: 6px;
                align-items: center;
                margin-bottom: 4px;
                color: var(--text-subtle);
            }

            .chunk-badge {
                font-size: 0.7rem;
                padding: 2px 6px;
                border-radius: 999px;
                border: 1px solid var(--border-subtle);
            }

            .chunk-text {
                font-size: 0.82rem;
            }

            .footer {
                margin-top: 10px;
                font-size: 0.78rem;
                color: var(--text-subtle);
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
                gap: 4px;
            }

            @media (max-width: 640px) {
                .card {
                    padding: 16px;
                    border-radius: 16px;
                }
                .title {
                    font-size: 1.1rem;
                }
                .right-controls {
                    align-items: flex-start;
                }
            }
        </style>
    </head>
    <body class="theme-light">
        <div class="shell">
            <div class="card">
                <div class="header">
                    <div class="title-block">
                        <div class="title">Document RAG QA</div>
                        <div class="subtitle">
                            Ask questions over your local knowledge base. Answers are grounded in retrieved chunks.
                        </div>
                        <div class="meta-row">
                            Indexed chunks: <strong>__TOTAL_CHUNKS__</strong> · Documents: <strong>__DOC_COUNT__</strong>
                        </div>
                    </div>
                    <div class="right-controls">
                        <div class="pill">RAG · sentence-transformers</div>
                        <div class="theme-toggle">
                            <button id="lightBtn" class="active">Light</button>
                            <button id="darkBtn">Dark</button>
                        </div>
                    </div>
                </div>

                <div class="field-label">Question</div>
                <textarea id="query" placeholder="Example: What is Retrieval Augmented Generation?"></textarea>

                <div class="controls">
                    <button id="askBtn" class="btn-primary">
                        <span>⚡</span>
                        <span>Ask</span>
                    </button>
                    <span style="font-size:0.8rem; color:var(--text-subtle);">Top K</span>
                    <input id="topK" type="number" value="3" min="1" max="20" />
                    <button id="clearBtn" class="btn-secondary">Clear</button>
                </div>

                <div id="status" class="status"></div>

                <div id="answerBlock" class="answer-block" style="display:none;">
                    <div class="answer-title">Answer</div>
                    <div id="answerText" class="answer-text"></div>
                    <div class="chips" id="chips"></div>
                    <div class="chunks-list" id="chunksList"></div>
                </div>

                <div class="footer">
                    <div>Logs and evaluation stored in <code>logs/eval_logs.json</code></div>
                    <div>Built by Mohamed Elsaka</div>
                </div>
            </div>
        </div>

        <script>
            const INDEX_TOTAL_CHUNKS = __TOTAL_CHUNKS__;
            const INDEX_DOC_COUNT = __DOC_COUNT__;

            const lightBtn = document.getElementById('lightBtn');
            const darkBtn = document.getElementById('darkBtn');
            const bodyEl = document.body;

            const askBtn = document.getElementById('askBtn');
            const clearBtn = document.getElementById('clearBtn');
            const queryEl = document.getElementById('query');
            const topKEl = document.getElementById('topK');
            const statusEl = document.getElementById('status');
            const answerBlock = document.getElementById('answerBlock');
            const answerText = document.getElementById('answerText');
            const chips = document.getElementById('chips');
            const chunksList = document.getElementById('chunksList');

            function setTheme(theme) {
                if (theme === "dark") {
                    bodyEl.classList.add("theme-dark");
                    lightBtn.classList.remove("active");
                    darkBtn.classList.add("active");
                } else {
                    bodyEl.classList.remove("theme-dark");
                    darkBtn.classList.remove("active");
                    lightBtn.classList.add("active");
                }
            }

            lightBtn.addEventListener("click", () => setTheme("light"));
            darkBtn.addEventListener("click", () => setTheme("dark"));

            clearBtn.addEventListener("click", () => {
                queryEl.value = "";
                answerBlock.style.display = "none";
                statusEl.textContent = "";
                chips.innerHTML = "";
                chunksList.innerHTML = "";
            });

            async function askQuestion() {
                const query = queryEl.value.trim();
                let topK = parseInt(topKEl.value) || 3;

                if (!query) {
                    statusEl.textContent = "Please type a question first.";
                    return;
                }

                if (topK > INDEX_TOTAL_CHUNKS) {
                    topK = INDEX_TOTAL_CHUNKS;
                    topKEl.value = INDEX_TOTAL_CHUNKS;
                }

                askBtn.disabled = true;
                statusEl.textContent = "Thinking...";
                answerBlock.style.display = "none";
                answerText.textContent = "";
                chips.innerHTML = "";
                chunksList.innerHTML = "";

                try {
                    const resp = await fetch("/ask", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ query, top_k: topK })
                    });

                    if (!resp.ok) {
                        statusEl.textContent = "Error from API: " + resp.status;
                        askBtn.disabled = false;
                        return;
                    }

                    const data = await resp.json();
                    statusEl.textContent = "";
                    answerBlock.style.display = "block";
                    answerText.textContent = data.answer || "(no answer)";

                    const chipCount = document.createElement("div");
                    chipCount.className = "chip";
                    chipCount.textContent = "Retrieved chunks: " + data.retrieved_chunks.length + " of " + INDEX_TOTAL_CHUNKS;
                    chips.appendChild(chipCount);

                    const chipDocs = document.createElement("div");
                    chipDocs.className = "chip";
                    chipDocs.textContent = "Documents: " + INDEX_DOC_COUNT;
                    chips.appendChild(chipDocs);

                    data.retrieved_chunks.forEach((c) => {
                        const item = document.createElement("div");
                        item.className = "chunk-item";

                        const header = document.createElement("div");
                        header.className = "chunk-header";
                        header.textContent = c.doc_id + " · chunk " + c.chunk_id;

                        const badge = document.createElement("span");
                        badge.className = "chunk-badge";
                        badge.textContent = "score " + c.score;
                        header.appendChild(badge);

                        const text = document.createElement("div");
                        text.className = "chunk-text";
                        text.textContent = c.text_preview;

                        item.appendChild(header);
                        item.appendChild(text);
                        chunksList.appendChild(item);
                    });

                } catch (err) {
                    console.error(err);
                    statusEl.textContent = "Something went wrong. Check the browser console.";
                } finally {
                    askBtn.disabled = false;
                }
            }

            askBtn.addEventListener("click", askQuestion);
            queryEl.addEventListener("keydown", (e) => {
                if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                    askQuestion();
                }
            });

            // init
            setTheme("light");
        </script>
    </body>
    </html>
    """

    # Inject numbers into placeholders
    html = html_template.replace("__TOTAL_CHUNKS__", str(total_chunks))
    html = html.replace("__DOC_COUNT__", str(doc_count))

    return HTMLResponse(content=html)


# ===============================
# EVALUATION METRICS + DASHBOARD
# ===============================

from fastapi.responses import JSONResponse
from pathlib import Path as _Path
import json as _json

METRICS_DIR = _Path(__file__).resolve().parent.parent / "metrics"


@app.get("/metrics")
def get_metrics():
    summary_path = METRICS_DIR / "summary.json"
    logs_path = METRICS_DIR / "eval_logs.jsonl"

    data = {"summary": None, "queries": []}

    if summary_path.exists():
        try:
            data["summary"] = _json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as exc:
            data["summary"] = {"error": str(exc)}

    if logs_path.exists():
        try:
            with logs_path.open("r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        data["queries"].append(_json.loads(line))
        except Exception as exc:
            data["queries"] = [{"error": str(exc)}]

    return JSONResponse(data)


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    return """<!DOCTYPE html>
<html>
<head>
    <title>RAG Evaluation Dashboard</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            background: #020617;
            color: #e5e7eb;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            padding: 40px;
        }
        .card {
            background: #111827;
            padding: 24px;
            border-radius: 20px;
            border: 1px solid #1f2937;
            max-width: 1100px;
            margin: 0 auto;
        }
        h1, h2, h3 {
            margin: 0 0 8px 0;
        }
        .summary {
            margin-bottom: 16px;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            margin-top: 16px;
        }
        th, td {
            border: 1px solid #1f2937;
            padding: 6px 8px;
            text-align: left;
        }
        th {
            background: #020617;
        }
        a {
            color: #38bdf8;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>RAG Evaluation Dashboard</h2>
        <div id="summary" class="summary">Loading...</div>
        <div id="table"></div>
        <br />
        <a href="/app">← Back to RAG UI</a>
    </div>

    <script>
        async function load() {
            const res = await fetch("/metrics");
            const data = await res.json();

            if (!data.summary) {
                document.getElementById("summary").innerText =
                    "No metrics found. Run the RAG evaluator first.";
                return;
            }

            const s = data.summary;
            document.getElementById("summary").innerHTML =
                "<b>Hit@K:</b> " + s.hit_at_k +
                " &nbsp; <b>MRR:</b> " + s.mrr +
                " &nbsp; <b>Queries:</b> " + s.n_queries;

            const q = data.queries || [];
            let html = "<table><tr><th>ID</th><th>Hit</th><th>RR</th><th>Rank</th></tr>";
            for (const row of q) {
                html += "<tr>" +
                    "<td>" + row.id + "</td>" +
                    "<td>" + row.hit_at_k + "</td>" +
                    "<td>" + row.reciprocal_rank + "</td>" +
                    "<td>" + row.first_relevant_rank + "</td>" +
                    "</tr>";
            }
            html += "</table>";
            document.getElementById("table").innerHTML = html;
        }
        load();
    </script>
</body>
</html>
"""


