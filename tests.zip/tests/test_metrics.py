from src.metrics import compute_per_query_metrics, aggregate_metrics


def test_per_query_metrics_basic():
    retrieved = ["doc_a.txt", "doc_b.txt", "doc_c.txt"]
    relevant = ["doc_b.txt"]
    m = compute_per_query_metrics(retrieved_doc_ids=retrieved, relevant_doc_ids=relevant, k=2)

    assert m.hit_at_k == 1.0
    assert abs(m.reciprocal_rank - 0.5) < 1e-6


def test_aggregate_metrics():
    m1 = compute_per_query_metrics(["a", "b"], ["b"], k=1)
    m2 = compute_per_query_metrics(["x", "y"], ["x"], k=1)

    agg = aggregate_metrics([m1, m2])
    assert agg.n_queries == 2
    assert agg.hit_at_k == 0.5
